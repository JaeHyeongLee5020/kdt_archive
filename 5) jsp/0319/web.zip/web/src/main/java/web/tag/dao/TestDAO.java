package web.tag.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import web.tag.dto.TestDTO;

public class TestDAO {
	
	// connection , close()를 메서드로 만든 후 호출하여 사용
	private Connection conn = null;			// DB 연결
	private PreparedStatement pstmt = null;	// SQL문 실행
	private ResultSet rs = null;			// 검색 결과 저장
	
	// DB 연결 객체를 리턴하는 메소드
	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@192.168.25.35:1521/xe";
			String user = "system";
			String password = "admin";
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	// DB 연결을 종료하는 메소드
	public void getClose() {
		try {if(conn != null) {conn.close();}} catch (Exception e) {e.printStackTrace();}
		try {if(pstmt != null) {pstmt.close();}} catch (Exception e) {e.printStackTrace();}
		try {if(rs != null) {rs.close();}} catch (Exception e) {e.printStackTrace();}
	}
	
	public int getInsert(TestDTO dto) {
		int result = 0;
		
		conn = getConnection();
		
		String sql = "insert into test(id, pw, name, age) values(?, ?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getName());
			pstmt.setInt(4, dto.getAge());
			
			// pstmt.executeQuery();	// 결과가 있는 쿼리문 (select)
			// pstmt.executeUpdate();	// 결과가 없는 쿼리문 (insert, update, delete)
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		getClose();
		return result;
	}
	
	public int idCheck(TestDTO dto) {
		int result = 0;
		getConnection();
		
		String sql = "select count(*) cnt from test where id = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			rs = pstmt.executeQuery();
			
			rs.next();
			
			// 해당 id가 사용되고있으면 1 , 사용되지 않으면 0
			result = rs.getInt("cnt");	// 매개변수는 컬럼명, 레코드가 1개이므로 반복문은 사용하지 않는다.
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		 
		getClose();
		return result;
	}
	
	public ArrayList getMember() {
		// return은 하나의 메서드에서 한번만 가능하기때문에 리턴 타입이 TestDTO가 아니라 List 타입을 리턴타입으로 지정
		ArrayList<TestDTO> memList = new ArrayList<TestDTO>();
		conn = getConnection();
		
		String sql = "select * from test";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				TestDTO dto = new TestDTO();

				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setAge(rs.getInt("age"));
				dto.setReg(rs.getTimestamp("reg"));
				memList.add(dto);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		getClose();
		return memList;
	}
	
	public int getMemCount() {
		int count = 0;
		conn = getConnection();
		
		String sql = "select count(*) memcnt from test";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			rs.next();
			
			count = rs.getInt("memcnt");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		getClose();
		return count;
	}
	
	
	public int getDelete(TestDTO dto) {
		int result = 0;
		conn = getConnection();
		
		String sql = "delete from test where id=? and pw=?";
		try { 
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			result = pstmt.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		getClose();
		return result;
	}
	
	public int memUpdate(TestDTO dto) {
		int result = 0;
		conn = getConnection();
		
		String sql = "update test set name=?, age=? where id=? and pw=?";
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, dto.getName());
			pstmt.setInt(2, dto.getAge());
			pstmt.setString(3, dto.getId());
			pstmt.setString(4, dto.getPw());
			
			result = pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		getClose();
		return result;
	}
	
	public boolean loginCheck(TestDTO dto) {
		// id와 password가 일치하면 true, 일치하지 않으면 false를 리턴
		boolean loginCheck = false;
		conn = getConnection();
		
		String sql = "select id from test where id=? and pw=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			rs = pstmt.executeQuery();
			// 꺼낼값이 있으면 true를 리턴 (id와 pw가 일치하면 true를 리턴)
			if(rs.next()) {
				loginCheck = true;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		getClose();
		return loginCheck;
	}
	
	public int myUpdate(TestDTO dto) {
		int result = 0;
		conn = getConnection();
		
		String sql = "update test set name=?, age=? where id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getName());
			pstmt.setInt(2,dto.getAge());
			pstmt.setString(3, dto.getId());
			result = pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		getClose();
		return result;
	}
	
	public TestDTO getMyinfo(String id) {
		TestDTO dto = new TestDTO();
		conn = getConnection();
		
		String sql ="select * from test where id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setAge(rs.getInt("age"));
				dto.setReg(rs.getTimestamp("reg"));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		getClose();
		return dto;
	}
	
	// 모든 회원정보를 리턴
	public ArrayList<TestDTO> getAllMember() {
		// 하나의 레코드가 하나의 DTO에 담겨지고 DTP를 ArrayList에 저장하여 리턴
		ArrayList<TestDTO> allList = new ArrayList<TestDTO>();
		
		conn = getConnection();
		
		String sql = "select * from test";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				TestDTO dto = new TestDTO();
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setAge(rs.getInt("age"));
				dto.setReg(rs.getTimestamp("reg"));
				allList.add(dto);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		getClose();
		return allList;
	}
	
	// 가입된 회원수
	public int getMemberCount() {
		int result = 0;
		conn = getConnection();
		
		String sql = "select count(*) memcnt from test";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = rs.getInt("memcnt");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		getClose();
		return result;
	}
	
	// 회원 탈퇴
	public int getMemberDelete(TestDTO dto) {
		int result = 0;
		conn = getConnection();
		
		String sql = "delete from test where id=? and pw=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			result = pstmt.executeUpdate();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		getClose();
		return result;
	}
}



























