package web.tag.dto;

public class Form4DTO {
	private String id;
	private String pw;
	private String[] ch;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String[] getCh() {
		return ch;
	}
	public void setCh(String[] ch) {
		this.ch = ch;
	}
}
