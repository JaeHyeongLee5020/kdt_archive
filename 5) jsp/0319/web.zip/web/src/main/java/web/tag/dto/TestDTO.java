package web.tag.dto;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class TestDTO {
	String id;
	String pw;
	String name;
	int age;
	Timestamp reg;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Timestamp getReg() {
		return reg;
	}
	public void setReg(Timestamp reg) {
		this.reg = reg;
	}
	
	// 년/월/일만 출력시 사용 (기존은 날짜와 시간을 모두 출력)
	public String getNewReg() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		String newReg = sdf.format(this.reg);
		return newReg;
	}
}


















