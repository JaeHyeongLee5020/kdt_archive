package web.tag.dto;

public class Form3DTO {
	private String id;
	private String pw;
	private String ch1;
	private String ch2;
	private String ch3;
	
	public String getId() {return id;}
	public void setId(String id) {this.id = id;}
	
	public String getPw() {return pw;}
	public void setPw(String pw) {this.pw = pw;}
	
	public String getCh1() {return ch1;}
	public void setCh1(String ch1) {this.ch1 = ch1;}
	
	public String getCh2() {return ch2;}
	public void setCh2(String ch2) {this.ch2 = ch2;}
	
	public String getCh3() {return ch3;}
	public void setCh3(String ch3) {this.ch3 = ch3;}
}
