package web.tag.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import web.tag.dto.CookieDTO;

public class CookieDAO {
	private Connection conn = null;			// DB 연결
	private PreparedStatement pstmt = null;	// SQL문 실행
	private ResultSet rs = null;			// 검색 결과 저장
	
	// DB 연결 객체를 리턴하는 메소드
	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@192.168.25.35:1521/xe";
			String user = "system";
			String password = "admin";
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	// DB 연결을 종료하는 메소드
	public void getClose() {
		try {if(conn != null) {conn.close();}} catch (Exception e) {e.printStackTrace();}
		try {if(pstmt != null) {pstmt.close();}} catch (Exception e) {e.printStackTrace();}
		try {if(rs != null) {rs.close();}} catch (Exception e) {e.printStackTrace();}
	}
	
	public boolean loginCheck(CookieDTO dto) {
		boolean result = false;
		getConnection();
		
		// select id from test where id='java' and pw='1234';
		String sql = "select id from test where id=? and pw=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				result = true;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}
		return result;
	}	
}

























