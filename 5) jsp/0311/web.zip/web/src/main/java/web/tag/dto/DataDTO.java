package web.tag.dto;

public class DataDTO {
	private String id;
	private String pw;
	private String data;
	private int age;
	private String name;
		
	public void setId(String id) {this.id = id;}
	public String getId() {return this.id;}
	public void setPw(String pw) {this.pw = pw;}
	public String getPw() {return this.pw;}
	public void setData(String data) {this.data = data;}
	public String getData() {return this.data;}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
}
