package web.test;
public class Tv {
	private int channel;
	private int volume;
	
	public Tv() {
//		this.channel = 10;
//		this.volume = 20;
	}
	
	public int getChannel() {
		return this.channel;
	}
	
	public int getVolume() {
		return this.volume;
	}
	
	public void setChannel(int channel) {
		this.channel = channel;
	}
	
	public void setVolume(int volume) {
		this.volume = volume;
	}
}
