package web.tag.dto;

public class CalculatorDTO {
	
	private int num1;
	private int num2;
	private String oper;
	private int result;
	private int errCode;	// 0=정상, 1=0으로 나누기 , 2=operErr
	
	public int getErrCode() {
		return errCode;
	}
	public void setErrCode(int errCode) {
		this.errCode = errCode;
	}
	public int getNum1() {
		return num1;
	}
	public void setNum1(int num1) {
		try { 
			this.num1 = num1;
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public int getNum2() {
		return num2;
	}
	public void setNum2(int num2) {
		try { 
			this.num2 = num2;
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper;
	}
	public int getResult() {
		if(oper.equals("+")) {
			result = num1 + num2;
		} else if(oper.equals("-")) {
			result = num1 - num2;
		} else if(oper.equals("*")) {
			result = num1 * num2;
		} else if(oper.equals("/")) {
			if(num2 == 0) {
				errCode = 1;	// 정수를 0으로 나누는 에러
				return 0;
			} else {
				result = num1 / num2;
			}
		} else {
			errCode = 2;
			result = 0;
		}
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
}










