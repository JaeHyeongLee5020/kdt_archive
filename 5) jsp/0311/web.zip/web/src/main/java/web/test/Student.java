package web.test;
public class Student {
	
	private String stdName;
	private int stdScore;
	
	public String getStdName() {
		return this.stdName;
	}
	
	public int getStdScore() {
		return this.stdScore;
	}
	
	public void setStdName(String name) {
		this.stdName = name;
	}
	
	public void setStdScore(int score) {
		this.stdScore = score;
	}
}
